<?php
/**
 * Plugin Name: Swiper Elementor Addon
 * Description: List widget for Elementor.
 * Plugin URI:  https://binarycodebd.com/
 * Version:     1.0.0
 * Author:      BinaryCodeBD
 * Author URI:  https://binarycodebd.com/
 * Text Domain: bcb-sea
 *
 * Requires Plugins: elementor
 * Elementor tested up to: 3.21.0
 * Elementor Pro tested up to: 3.21.0
 */

 if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Register List Widget.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function register_list_widget( $widgets_manager ) {

	require_once( __DIR__ . '/widgets/swiper-slider.php' );

	$widgets_manager->register( new \BCB_Swiper_Slider() );

}
add_action( 'elementor/widgets/register', 'register_list_widget' );


/**
 * Enqueue Widget Scripts.
 *
 * Enqueue widget scripts.
 *
 * @since 1.0.0
 * @return void
 */
function enqueue_widget_scripts() {
    wp_enqueue_script(
        'bcb-sea-swiper-slider',
        plugins_url( '/assets/js/swiper.js', __FILE__ ),
        [ 'elementor-frontend' ],
        '1.0.0',
        [ 'in_footer' => true ]
    );

    wp_enqueue_script(
        'bcb-main',
        plugins_url( '/assets/js/main.js', __FILE__ ),
        [ 'jquery', 'elementor-frontend', 'bcb-sea-swiper-slider' ],
        '1.0.0',
        [ 'in_footer' => true ]
    );
}
add_action( 'elementor/frontend/after_register_scripts', 'enqueue_widget_scripts' );


/**
 * Enqueue Widget Styles.
 *
 * Enqueue widget styles.
 *
 * @since 1.0.0
 * @return void
 */
function enqueue_widget_styles() {

    wp_enqueue_style(
        'bcb-sea-swiper-slider',
        plugins_url( '/assets/css/swiper.css', __FILE__ )
    );

    wp_enqueue_style(
        'bcb-main',
        plugins_url( '/assets/css/main.css', __FILE__ )
    );
}
add_action( 'elementor/frontend/after_register_styles', 'enqueue_widget_styles' );