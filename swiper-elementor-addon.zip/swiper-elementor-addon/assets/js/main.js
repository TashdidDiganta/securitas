;(function($){
    "use strict";
    $(document).ready(function(){
        var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            spaceBetween: 0,
            freemode:true,
            centeredSlide:true,
            loop: true,
            speed: 500,
            navigation: {
              clickable: true,
              nextEl: ".swiper-slide-next",
              prevEl: ".swiper-slide-prev",
            },
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
              renderBullet: function (index, className) {
                return '<span class="' + className + '">' + (index + 1) + "</span>";
              },
            },
      
        });
    })
    
})(jQuery);