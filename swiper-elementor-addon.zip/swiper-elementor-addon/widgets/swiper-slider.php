<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor List Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BCB_Swiper_Slider extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve list widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bcb-swiper-slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve list widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'BCB Swiper Slider', 'bcb-sea' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve list widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the list widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the list widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'slider', 'swiper-slider' ];
	}

	/**
	 * Get custom help URL.
	 *
	 * Retrieve a URL where the user can get more information about the widget.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget help URL.
	 */
	public function get_custom_help_url() {
		return 'https://developers.elementor.com/docs/widgets/';
	}

	/**
	 * Get widget promotion data.
	 *
	 * Retrieve the widget promotion data.
	 *
	 * @since 1.0.0
	 * @access protected
	 * @return array Widget promotion data.
	 */
	protected function get_upsale_data() {
		return [
			'condition' => true,
			'image' => esc_url( ELEMENTOR_ASSETS_URL . 'images/go-pro.svg' ),
			'image_alt' => esc_attr__( 'Upgrade', 'elementor-list-widget' ),
			'title' => esc_html__( 'Promotion heading', 'elementor-list-widget' ),
			'description' => esc_html__( 'Get the premium version of the widget with additional styling capabilities.', 'elementor-list-widget' ),
			'upgrade_url' => esc_url( 'https://example.com/upgrade-to-pro/' ),
			'upgrade_text' => esc_html__( 'Upgrade Now', 'elementor-list-widget' ),
		];
	}

	/**
	 * Register list widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		$this->start_controls_section(
			'style_content_section',
			[
				'label' => esc_html__( 'List Style', 'elementor-list-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'elementor-list-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-list-widget-text' => 'color: {{VALUE}};',
					'{{WRAPPER}} .elementor-list-widget-text > a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'selector' => '{{WRAPPER}} .elementor-list-widget-text, {{WRAPPER}} .elementor-list-widget-text > a',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '{{WRAPPER}} .elementor-list-widget-text',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'style_marker_section',
			[
				'label' => esc_html__( 'Marker Style', 'elementor-list-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'marker_color',
			[
				'label' => esc_html__( 'Color', 'elementor-list-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-list-widget-text::marker' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'marker_spacing',
			[
				'label' => esc_html__( 'Spacing', 'elementor-list-widget' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', 'em', 'rem', 'custom' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
					'em' => [
						'min' => 0,
						'max' => 10,
					],
					'rem' => [
						'min' => 0,
						'max' => 10,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					// '{{WRAPPER}} .elementor-list-widget' => 'padding-left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementor-list-widget' => 'padding-inline-start: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

    public function get_script_depends() {
        return [ 'bcb-sea-swiper-slider', 'bcb-main' ];
    }

	/**
	 * Render list widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        <section class="td-slider-area">
            <div class="swiper mySwiper">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="slider-item">
                            <div class="slider-content">
                                <h2>Certifying Data Center Professionals</h2>
                                <p>Driven by dedication to provide security tailored to meet the challenges in the markets
                                    where we operate.</p>
                                <div class="card-btn">
                                    <a href="#">Read More</a>
                                </div>
                            </div>
                            <div class="slider-img">
                                <img src="<?php echo esc_url(plugin_dir_url(__DIR__)); ?>/assets/img/slider01.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slider-item">
                            <div class="slider-content">
                                <h2>Certifying Data Center Professionals</h2>
                                <p>Driven by dedication to provide security tailored to meet the challenges in the markets
                                    where we operate.</p>
                                <div class="card-btn">
                                    <a href="#">Read More</a>
                                </div>
                            </div>
                            <div class="slider-img">
                                <img src="<?php echo esc_url(plugin_dir_url(__DIR__)); ?>/assets/img/slider01.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slider-item">
                            <div class="slider-content">
                                <h2>Certifying Data Center Professionals</h2>
                                <p>Driven by dedication to provide security tailored to meet the challenges in the markets
                                    where we operate.</p>
                                <div class="card-btn">
                                    <a href="#">Read More</a>
                                </div>
                            </div>
                            <div class="slider-img">
                                <img src="<?php echo esc_url(plugin_dir_url(__DIR__)); ?>/assets/img/slider02.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slider-item">
                            <div class="slider-content">
                                <h2>Certifying Data Center Professionals</h2>
                                <p>Driven by dedication to provide security tailored to meet the challenges in the markets
                                    where we operate.</p>
                                <div class="card-btn">
                                    <a href="#">Read More</a>
                                </div>
                            </div>
                            <div class="slider-img">
                                <img src="<?php echo esc_url(plugin_dir_url(__DIR__)); ?>/assets/img/slider03.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slider-item">
                            <div class="slider-content">
                                <h2>Certifying Data Center Professionals</h2>
                                <p>Driven by dedication to provide security tailored to meet the challenges in the markets
                                    where we operate.</p>
                                <div class="card-btn">
                                    <a href="#">Read More</a>
                                </div>
                            </div>
                            <div class="slider-img">
                                <img src="<?php echo esc_url(plugin_dir_url(__DIR__)); ?>/assets/img/slider04.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="slider-item">
                            <div class="slider-content">
                                <h2>Certifying Data Center Professionals</h2>
                                <p>Driven by dedication to provide security tailored to meet the challenges in the markets
                                    where we operate.</p>
                                <div class="card-btn">
                                    <a href="#">Read More</a>
                                </div>
                            </div>
                            <div class="slider-img">
                                <img src="<?php echo esc_url(plugin_dir_url(__DIR__)); ?>/assets/img/slider05.jpg" class="d-block w-100" alt="...">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-handle">
                    <div class="swiper-slide-prev">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" width="16" height="16"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#FFF" d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg>
                    </div>
                    <div class="swiper-slide-next">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" width="16" height="16"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#FFF" d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
                    </div>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </section>
        <?php if(\Elementor\Plugin::instance()->editor->is_edit_mode()): ?>
            <script>
                var swiper = new Swiper(".mySwiper", {
                    slidesPerView: 1,
                    spaceBetween: 0,
                    freemode:true,
                    centeredSlide:true,
                    loop: true,
                    speed: 500,
                    navigation: {
                    clickable: true,
                    nextEl: ".swiper-slide-next",
                    prevEl: ".swiper-slide-prev",
                    },
                    pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                    renderBullet: function (index, className) {
                        return '<span class="' + className + '">' + (index + 1) + "</span>";
                    },
                    },
            
                });
            </script>
        <?php endif; ?>
        <?php
	}

}
